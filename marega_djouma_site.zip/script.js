// Tu peux ajouter ici des fonctionnalités JavaScript si besoin plus tard
